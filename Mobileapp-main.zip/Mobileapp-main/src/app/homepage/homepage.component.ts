import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {MatDialog} from '@angular/material/dialog';
import { SignupComponent } from '../signup/signup.component';
import { AddtocartComponent } from '../addtocart/addtocart.component';
import { MyserviceService } from '../myservice.service';
import { HttpClient } from '@angular/common/http';



@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {


  mobiledetails:any=[];

  constructor(private rout:Router,private dialog:MatDialog,private service:MyserviceService) { }


  logodata:string="assets/images/mobile logo.png"
  banner:string="assets/images/bannerimg.jpg"

  ngOnInit()
  {

this.service.mobiledetailss().subscribe((res:any[]) => this.mobiledetails = res)
  
console.log(this.mobiledetails.value)


  }
  signupDialog()
  {
const dilogsignup=this.dialog.open(SignupComponent,{panelClass:'dilaogborder'});
dilogsignup.afterClosed().subscribe(result =>
  {

  });
  }

addtocart()
{
  const dialogadd = this.dialog.open(AddtocartComponent,{panelClass:'dialogborder'});
  dialogadd.afterClosed().subscribe(result=>{

  });
}












}
