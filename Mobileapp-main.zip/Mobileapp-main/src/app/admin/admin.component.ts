import { Component, OnInit } from '@angular/core';
import { MyserviceService } from '../myservice.service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import {MatTableDataSource} from '@angular/material/table';
import { tablevalue } from '../supportts';



@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {



displayedColumns: string[] = ['_id','username', 'emailid', 'mobilenumber','isrole','action'];
dataSource = new MatTableDataSource<tablevalue>();


  constructor( private tableservice:MyserviceService,private route:Router,
    private httpclent:HttpClient,private activaterouter:ActivatedRoute) 
  { }

  ngOnInit(): void {




    this.displayontable()
  }







displayontable()
{

  this.tableservice.tabledatavalue().subscribe((res:any) => this.dataSource.data = res as tablevalue[])
}
diactivete(row:any)
{
  var res1 ="delete success"
  var res2 ="data can't delete"
this.tableservice.deleteuser(row).subscribe(
  res => 
  {
    if(res)
    {
      alert(res1)
      window.location.reload();
      
    }
    else{
      alert(res2)
    }

  })
}


addmobiledetails()
{
  this.route.navigate(['/adddetails'])
}






}
