import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { FormGroup,FormControl,Validators, NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { MyserviceService } from '../myservice.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  


form =new FormGroup({



  username:new FormControl('',[Validators.required,Validators.pattern('[a-zA-Z]+')]),
  emailid:new FormControl('',[Validators.required,Validators.email]),
  password:new FormControl('',[Validators.required,Validators.minLength(7),Validators.pattern('((?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,30})')]),
  mobilenumber:new FormControl('',[Validators.required,Validators.pattern("[0-9]{10}$")]),
  isrole:new FormControl('user')

})


formlogin =new FormGroup({

  username:new FormControl('',[Validators.required,Validators.pattern('[a-zA-Z]+')]),
  password:new FormControl('',[Validators.required,Validators.minLength(7),Validators.pattern('((?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,30})')]),



})




  constructor(private matdialog:MatDialog,private route:Router,private service:MyserviceService) { }


hide=true;

 
  signup:string="assets/images/signup.png"

  ngOnInit(): void {






  }




  onSubmit()
  {
    var success ="register Success"
    var failed="check your field properly"
  console.log(this.form.value)
  this.service.register(this.form.value).subscribe(
    res=>
    {
      if(res)
      {
        this.form.reset()
        this.matdialog.closeAll()
        alert(success)

      }
      else{
        alert(failed)
      }

    })
  
  }
  




loginvalue()
{
  var success ="Login success"
  var failed ="failed login"
  console.log(this.formlogin.value);
  
this.service.loginvalue(this.formlogin.value).subscribe(
  res=>
  {
if(res)
{

  for(let values of Object.values(res))
  {
    if(values == "user")
    {
     this.route.navigate(['/user'])
    }
    else if(values == "admin")
    {
  this.route.navigate(['/admin'])
    }
  }


}
  },err =>
  {
  alert("enter proper field")
  })


 this.matdialog.closeAll()

 this.formlogin.reset()

}




// console.log(this.formlogin.value.usernamelogin);
// var user = this.formlogin.value.usernamelogin
// var adminvalue="admin"
// var end=user.endsWith('admin')
// console.log(end);
// if(end == true)
// {
//   this.matdialog.closeAll();
//   this.route.navigate(['/admin'])

// }
// else if(end == false)
// {
//   this.matdialog.closeAll();
//   this.route.navigate(['/user'])
// }
// else
// {
//   this.matdialog.closeAll();
// console.log("user not found")
// }













}
