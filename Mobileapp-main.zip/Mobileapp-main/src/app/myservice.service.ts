import { Injectable,Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { register,signin,tablevalue,del,admingetdetails,displaymobiledetails} from './supportts';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';



@Injectable({
  providedIn: 'root'
})
export class MyserviceService {
 

  //Register

  private registerurl:string="http://localhost:3000/api/mobileregister";
  private loginurl:string="http://localhost:3000/api/authenticate";



  //User Side
private getmobiledetails:string="http://localhost:3000/api/viewmobiledetails";

  

// Admin Side
  private adminmobiledetail:string="http://localhost:3000/api/mobiledtl"
  private tablevalue:string="http://localhost:3000/api/getdbvalue";
  private deletedata:string="http://localhost:3000/api/delete"
  // baseUrl:string;
  constructor(private http:HttpClient) {
      // this.baseUrl = environment.apiUrl;
      
   }




//common Side
register(reg:register)
{
  return this.http.post(this.registerurl,reg)
}
loginvalue(sign:signin)
{
  return this.http.post(this.loginurl,sign)
}
sendEmail(url: string, data: any) {
  return this.http.post(url, data);
}

// userRegister(data:any):Observable<any[]>{
//   return this.http.post<any[]>(`${this.baseUrl+'/sendmail'}`, data); 
// }

setToken(token:string)

{
console.log(token)
localStorage.setItem("token",token)
}



//              User Side

mobiledetailss()
{

 return this.http.get<displaymobiledetails[]>(this.getmobiledetails)

}





//Admin side

admininsertdetails(admin:admingetdetails)
{
  return this.http.post(this.adminmobiledetail,admin)
}

deleteuser(del:any):Observable<any>
{

  return this.http.post(this.deletedata,del)

}

tabledatavalue()
{
  return this.http.get<tablevalue[]>(this.tablevalue);

}













}
