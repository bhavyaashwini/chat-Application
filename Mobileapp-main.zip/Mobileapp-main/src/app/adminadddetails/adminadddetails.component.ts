import { Component, Input, OnInit } from '@angular/core';
import { MyserviceService } from '../myservice.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { FormControl, FormGroup } from '@angular/forms';
import { Validators } from '@angular/forms';


@Component({
  selector: 'app-adminadddetails',
  templateUrl: './adminadddetails.component.html',
  styleUrls: ['./adminadddetails.component.css']
})
export class AdminadddetailsComponent implements OnInit {

  
  

public  value:any


 
   
   

adminform = new FormGroup(

  {

    

   mobileimg :new FormControl( ),
    mobilebrand:new FormControl('',[Validators.maxLength(9),Validators.required]),
    mobilemodel:new FormControl('',Validators.required),
    mobileprice:new FormControl('',[Validators.required]),
    mobileinternal:new FormControl('',Validators.required),
    mobileexternal:new FormControl('',Validators.required),
    mobileram:new FormControl('',Validators.required),
    mobilecolor:new FormControl('',Validators.required),
    
    
    
    
  }
)




  constructor(private service:MyserviceService,private route:Router,private http:HttpClient) { }




  ngOnInit(): void {




  }


  
 



  imageselect(event:any)
  {
    

		var reader = new FileReader();
		reader.readAsDataURL(event.target.files[0]);
    

		reader.onload = (_event:any) => {
		 this.value = reader.result
  
   



    


  


		}
  }



  
  Cancel()
  {
    this.adminform.reset();
  
  }

  onSubmit()
  {
    console.log(this.adminform.value);
    
this.service.admininsertdetails(this.adminform.value).subscribe(res=>
  {
    if(res)
    {
      alert("stored")
    }
    else{
      alert("failed")
    }
  }


  
)






this.adminform.reset();


  }














}

