
const mongoose = require('mongoose');
const passport = require('passport');
const _ = require('lodash');
const router = require('../router/index.router');
const { get, replace, values } = require('lodash');
const { authenticate } = require('passport');

const reg = mongoose.model('reg')


const mob = mongoose.model('mobiledetails')




module.exports.mobileregister = (req,res,next) =>
{

var regi = new reg();
regi.username=req.body.username;
regi.emailid=req.body.emailid;
regi.password=req.body.password;
regi.mobilenumber=req.body.mobilenumber;
regi.isrole=req.body.isrole;

regi.save((err,doc) => {
    if(!err) 
    {
        console.log(doc)
        res.send(doc);
    }
    else
    {
        console.log(err);
    }
});
}












module.exports.authenticate =(req,res,next) =>
{
    
    passport.authenticate('local',(err,reg,info) => {

        if(err)
        return res.status(400).json(err);
        else if(reg,req)  
        {
        return res.status(200).json({"token":reg.generateJwt(),"_id":reg._id,"username":reg.username,"isrole":reg.isrole,"email":reg.emailid
    });
        }

        else
        return res.status(404).json(info);
    
    }) (req,res);
 

    
}


module.exports.userprofile=(req,res,next)=>
{
reg.findOne({_id:req._id},(err,value)=>
{
    console.log(req._id)
    if(!value)
    {
    return res.status(404).json({status:false,message:'User record not found'});
    }
    else{
        return res.status(200).json({status:true,value : _.pick(value,['username','emailid'])})
    }
})

}














module.exports.update = (req,res)=>
{
   
    reg.findOneAndUpdate({emailid:req.body.emailid},req.body,{new:true, useFindAndModify: false})
    .then(reg =>{
        if(!reg)
        {
            return res.status(404).json({
                msg:" customer email not found " + req.params.emailid
            });
        }
        res.json(reg);
    }).catch(err =>
    {
        if(err.kind ==='emailid')
        {
            return res.status(404).json({
                msg:" customer email not found " + req.params.emailid
            });

        }
        return res.status(500).json({
            msg:" error Updating Emailid " + req.params.emailid

        });
    }) ;
  
}



module.exports.getdbvalue =(req,res)=>
{
    reg.find({isrole:"user"}).
    then(reg => 
        {
            res.json(reg);

    }).catch(err =>
        {
            res.status(500).send({
                msg : err.message
            });
        });
}



module.exports.viewmobiledetails=(req,res)=>
{
    mob.find().then(mob =>
        {
            res.json(mob);
        }).catch(err =>
            
            {
                res.status(500).send({
                    msg : err.message
                });

            });
    
}


















module.exports.delete=(req,res)=>
{
    
    reg.findByIdAndRemove(req.body._id,{useFindAndModify:false})
    .then(data => {
        if(!data)
        {
            res.status(404).send({message :"ID not found"});

        }
        else
        {
            res.send({message:"data delete successfully"})
        }
    })
    .catch(err =>{
        res.status(500).send({message :" value could not delete"})
    })
}




module.exports.disable=(req,res) =>
{
    reg.findByIdAndRemove(req.body._id,{useFindAndModify:false})
    .then(data =>{
        if(!data)
        {
            res.status(404).send({message :"ID not found"});

        }
        else{
            res.send({message:"disable the users"})
        }

    }).catch(err=>
        {
            res.status(500).send({message :" value could not disable"})
        })

}



////admin side details





//Insert mobiledetails from admin


module.exports.mobledtl=(req,res,next)=>
{
    var mobile = new mob();

    mobile.mobileimg=req.body.mobileimg;
    mobile.mobilebrand=req.body.mobilebrand;
    mobile.mobilemodel=req.body.mobilemodel;
    mobile.mobileprice=req.body.mobileprice;
    mobile.mobileinternal=req.body.mobileinternal;
    mobile.mobileexternal=req.body.mobileexternal;
    mobile.mobileram=req.body.mobileram;
    mobile.mobilecolor=req.body.mobilecolor;


    mobile.save((err,doc) => {
        if(!err) 
        {
            console.log(doc)
            res.send(doc);
        }
        else
        {
            console.log(err);
        }
    });
}







