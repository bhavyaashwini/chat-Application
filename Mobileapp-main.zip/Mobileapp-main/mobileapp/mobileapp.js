require('./config/config');
require('./models/db');
require('./config/passportconfig'); 
const express = require('express');
 cors = require('cors');


const rtsIndex = require('./router/index.router');
const bodyParser = require('body-parser');
const passport =require('passport');



var app=express();

app.use(bodyParser.json());


console.log('app'); 

 app.use(passport.initialize());
 

app.use(cors());
app.use('/api',rtsIndex);

'/api/register'
'/api/authenticate'

app.listen(process.env.PORT,() => console.log(`server start PORT : ${process.env.PORT}`)); 

