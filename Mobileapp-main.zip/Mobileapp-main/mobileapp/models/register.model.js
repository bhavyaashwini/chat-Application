const mongoose = require('mongoose');
//const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');



var regschema = new mongoose.Schema({

    username :
    {
        type:String
    },  
    emailid :{type:String},
    password:{type:String},
    mobilenumber:{type:String},
    isrole:{type:String},
    isActive:{
type:Boolean,
default:true
    },

   
    SaltSecret:String


});





var mobiledetails = new mongoose.Schema(
    {
     mobileimg:{type:String},
     mobilebrand:{type:String},
     mobilemodel:{type:String},
     mobileprice:{type:String},
     mobileinternal:{type:String},
     mobileexternal:{type:String},
     mobilecolor:{type:String},

     SaltSecret:String




    }
)


regschema.methods.validpassword = function(password)
{
    if(password == this.password)
    {
        return true;
    }
    else
    {
        return false;
    }
}


regschema.methods.generateJwt = function()
        {
            return jwt.sign({_id: this._id},
                process.env.JWT_SECRET,
            {
                expiresIn :process.env.JWT_EXP
            });
        }
      


        






mongoose.model('reg',regschema);



mongoose.model('mobiledetails',mobiledetails)
console.log('jfsjbjdbkv');