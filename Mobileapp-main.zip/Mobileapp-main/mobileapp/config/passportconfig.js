const passport = require('passport');   
const localStrategy = require('passport-local').Strategy;
const mongoose = require('mongoose');



var reg = mongoose.model('reg')

passport.use(
    new localStrategy(
        
        
       function (username,password,done)  {


            reg.findOne({username:username},(err,reg)=>
    {    
        if(err)
        {
            
        
            return done(err);
        }
       

        else if(!reg)
        {   
                 return done(null, false,{message:'Pls Contact your Admin'});
        
         }

        else if(!reg.validpassword(password))
        {
        
            return done(null,false, {message:'wrong password.'});
        }


        else 
        {
            return done(null, reg);

        }
    })
})
);